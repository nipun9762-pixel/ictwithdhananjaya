# Tuition LMS - Complete Project

A simple Learning Management System for tuition teachers built with pure PHP, MySQL, HTML, CSS & JavaScript.

## Features

### Student Side
- Register / Login
- View all class cards
- Upload payment slip
- Access class content only after teacher approval
- View: Live class links, Recordings, Notes/Tutes, Notices

### Teacher Side
- Dashboard with stats
- Add / Edit / Deactivate class cards
- Approve or Reject payment slips
- Upload content (Live links, Recordings, Notes, Notices)

## How to Run (XAMPP / Laragon)

1. **Extract** this folder into:
   - XAMPP → `C:\xampp\htdocs\tuition-lms`
   - Laragon → `C:\laragon\www\tuition-lms`

2. **Start** Apache + MySQL

3. **Import Database**
   - Open phpMyAdmin → http://localhost/phpmyadmin
   - Create a new database or just import `database.sql`
   - The SQL file already creates the database `tuition_lms`

4. **Configure** (if needed)
   - Open `includes/config.php`
   - Change `$pass` if your MySQL has a password
   - Change `BASE_URL` if your folder name is different

5. **Open the website**
   - http://localhost/tuition-lms

## Default Teacher Login

- **Email:** teacher@tuition.com  
- **Password:** teacher123

> Please change the password after first login.

## Folder Structure

```
tuition-lms/
├── assets/
│   ├── css/style.css
│   ├── js/script.js
│   └── uploads/          ← payment slips, notes, recordings go here
├── includes/
│   ├── config.php
│   ├── auth.php
│   ├── header.php
│   └── footer.php
├── student/
│   ├── dashboard.php
│   ├── classes.php
│   ├── upload-payment.php
│   └── class-view.php
├── teacher/
│   ├── dashboard.php
│   ├── classes.php
│   ├── class-form.php
│   ├── payments.php
│   └── upload-content.php
├── index.php
├── login.php
├── register.php
├── logout.php
└── database.sql
```

## Important Notes

- Make sure the folders inside `assets/uploads/` have write permission.
- For production, move uploads outside the public folder and add proper security.
- This is a basic educational project. Add CSRF protection, better validation, and HTTPS before using in real production.

Enjoy!
