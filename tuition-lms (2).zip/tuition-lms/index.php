<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once 'includes/auth.php';
$pageTitle = 'Welcome - Tuition LMS';
$stmt = $pdo->query("SELECT id, title, description, fee, duration_days, thumbnail FROM classes WHERE is_active = 1 ORDER BY created_at DESC");
$classes = $stmt->fetchAll();
require 'includes/header.php';
?>

<!-- HERO SECTION -->
<section class="hero-modern">
    <div class="hero-content">
        <h1>Access to <span>Class Recordings</span></h1>
        <p>
            Upload your class card or the payment slip for this month, you can unlock
            all benefits by uploading a clear photo of it. These benefits include 50%
            paid courses and Free access to the recordings of this month’s
            Online and Physical classes.
        </p>
        <?php if ($user): ?>
            <a href="<?= BASE_URL ?>/<?= $user['role'] === 'teacher' ? 'teacher' : 'student' ?>/dashboard.php" class="btn-hero">Go to your dashboard →</a>
        <?php else: ?>
            <a href="<?= BASE_URL ?>/register.php" class="btn-hero">Upload Class Card or Payment Slip →</a>
        <?php endif; ?>
    </div>
    <div class="hero-image">
        <div class="hero-slider" data-hero-slider aria-label="Educator photos">
            <div class="hero-slider-track">
                <div class="hero-slide active" aria-hidden="false">
                    <img src="/assets/images/p1.jpg" alt="Your ICT educator">
                </div>
                <div class="hero-slide" aria-hidden="true">
                    <img src="/assets/images/hero-teacher.png" alt="Your ICT educator">
                </div>
            </div>
            <button class="hero-slider-control hero-slider-prev" type="button" aria-label="Show previous photo">&#10094;</button>
            <button class="hero-slider-control hero-slider-next" type="button" aria-label="Show next photo">&#10095;</button>
            <div class="hero-slider-dots" aria-label="Choose a photo">
                <button class="hero-slider-dot active" type="button" aria-label="Show photo 1" aria-pressed="true"></button>
                <button class="hero-slider-dot" type="button" aria-label="Show photo 2" aria-pressed="false"></button>
            </div>
        </div>
    </div>
</section>

<!-- POPULAR COURSES -->
<section class="popular-courses" id="courses">
    <div class="section-header">
        <h2>See Our <span>Popular Courses</span></h2>
        <a href="#courses" class="btn-outline">View all courses ↓</a>
    </div>

    <div class="course-grid">
        <?php if ($classes): ?>
            <?php foreach ($classes as $class): ?>
                <?php
                $classDescription = $class['description'] ?? '';
                $shortDescription = substr($classDescription, 0, 140);
                $courseUrl = $user
                    ? BASE_URL . '/' . ($user['role'] === 'teacher' ? 'teacher' : 'student') . '/classes.php'
                    : BASE_URL . '/register.php';
                ?>
                <article class="course-card">
                    <div class="course-img">
                        <img
                            src="/assets/<?= !empty($class['thumbnail']) ? 'uploads/class-thumbnails/' . rawurlencode(basename($class['thumbnail'])) : 'images/p2.png' ?>"
                            alt="<?= htmlspecialchars($class['title']) ?>"
                        >
                    </div>
                    <div class="course-body">
                        <span class="tag">Course</span>
                        <h3><?= htmlspecialchars($class['title']) ?></h3>
                        <?php if ($classDescription !== ''): ?>
                            <p><?= nl2br(htmlspecialchars($shortDescription)) ?><?= strlen($classDescription) > 140 ? '…' : '' ?></p>
                        <?php endif; ?>
                        <div class="price">Rs.<?= number_format((float)$class['fee'], 2) ?></div>
                        <div class="meta">
                            <span><?= (int)$class['duration_days'] ?> days</span>
                        </div>
                        <a href="<?= htmlspecialchars($courseUrl) ?>" class="btn btn-outline"><?= $user ? 'View course' : 'Sign up to enroll' ?></a>
                    </div>
                </article>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="course-empty">New courses are coming soon. Contact us on WhatsApp to learn more.</p>
        <?php endif; ?>
    </div>
</section>

<!-- STATS BAR -->
<section class="stats-bar">
    <div class="stat">
        <h3>15+</h3>
        <p>Course</p>
    </div>
    <div class="stat">
        <h3>2+</h3>
        <p>Years Experience</p>
    </div>
    <div class="stat">
        <h3>1</h3>
        <p>Expert Tutor</p>
    </div>
    <div class="stat">
        <h3>100+</h3>
        <p>Satisfied Students</p>
    </div>
</section>

<!-- MEET EDUCATOR -->
<section class="educator" id="educator">
    <h2>Meet Your Educator</h2>
    <div class="educator-card">
        <img src="/assets/images/p4.jpg" alt="Teacher">
        <div>
            <h3>Dhananjaya Edirisinghe</h3>
            <p>-Educator- <br>I'm Nipun Dhananjaya, an undergraduate at SLIIT pursuing a degree in Information Technology, specializing in Software Engineering. Alongside my academic journey, Im leading a freelance software development startup, gaining practical industry experience. I’m passionate about ICT education and helping students understand technology through simple explanations and real-world examples.</p>
        </div>
    </div>
</section>
<section class="reviews" id="reviews-section">
    <div class="container">
        <div class="reviews-heading">
            <h2>What Our <span class="highlight">Students</span> Say</h2>
            <p class="section-subtitle">Real feedback from our students</p>
        </div>

        <div class="reviews-grid" aria-label="Student reviews, scroll horizontally" tabindex="0">

            <!-- Card 1 -->
            <div class="review-tile">
                <div class="stars">★★★★★</div>
                <p class="review-text">"The classes are very clear and the recordings help a lot. I improved a lot in ICT after joining."</p>
                <div class="reviewer">
                    <div class="avatar">KP</div>
                    <div>
                        <h4>Sethumi Perera</h4>
                        <span>St .Peters collage,Negombo • Grade 10</span>
                    </div>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="review-tile">
                <div class="stars">★★★★★</div>
                <p class="review-text">"Best tuition for A/L ICT. Notes and live classes are excellent. Highly recommended!"</p>
                <div class="reviewer">
                    <div class="avatar">NS</div>
                    <div>
                        <h4>Nethmi Silva</h4>
                        <span>MahaMaya Vidyalaya Kandy • Grade 11</span>
                    </div>
                </div>
            </div>

            <!-- Card 3 -->
            <div class="review-tile">
                <div class="stars">★★★★☆</div>
                <p class="review-text">"Teacher explains everything simply. The monthly payment system is also very convenient."</p>
                <div class="reviewer">
                    <div class="avatar">DF</div>
                    <div>
                        <h4>Dilshan Fernando</h4>
                        <span>Ananda College • Grade 12</span>
                    </div>
                </div>
            </div>

            <!-- Card 4 -->
            <div class="review-tile">
                <div class="stars">★★★★★</div>
                <p class="review-text">"I love the recordings. I can watch them anytime. Very helpful for revision."</p>
                <div class="reviewer">
                    <div class="avatar">SJ</div>
                    <div>
                        <h4>Sachini Jayawardena</h4>
                        <span>Mahamaya Girls College • Grade 12</span>
                    </div>
                </div>
            </div>

            div class="review-tile">
                <div class="stars">★★★★★</div>
                <p class="review-text">"I love the recordings. I can watch them anytime. Very helpful for revision."</p>
                <div class="reviewer">
                    <div class="avatar">SJ</div>
                    <div>
                        <h4>Senaya jayakody</h4>
                        <span>St Peters College,Negombo • Grade 10</span>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<?php require 'includes/footer.php'; ?>
