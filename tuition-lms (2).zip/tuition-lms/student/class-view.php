<?php
require_once '../includes/auth.php';
requireRole('student');

$class_id = (int)($_GET['id'] ?? 0);

if (!hasClassAccess($_SESSION['user_id'], $class_id)) {
    die('<div style="padding:40px;text-align:center;"><h2>Access Denied</h2><p>You do not have an approved enrollment for this class.</p><a href="classes.php">Go back</a></div>');
}

$stmt = $pdo->prepare("SELECT * FROM classes WHERE id = ?");
$stmt->execute([$class_id]);
$class = $stmt->fetch();

$stmt = $pdo->prepare("SELECT * FROM class_content WHERE class_id = ? ORDER BY created_at DESC");
$stmt->execute([$class_id]);
$contents = $stmt->fetchAll();

$live = $recordings = $notes = $notices = [];
foreach ($contents as $item) {
    if ($item['type'] === 'live_link') $live[] = $item;
    elseif ($item['type'] === 'recording') $recordings[] = $item;
    elseif ($item['type'] === 'note') $notes[] = $item;
    elseif ($item['type'] === 'notice') $notices[] = $item;
}

$pageTitle = $class['title'];
require '../includes/header.php';
?>

<div class="class-header">
    <h1><?= htmlspecialchars($class['title']) ?></h1>
    <p><?= nl2br(htmlspecialchars($class['description'] ?? '')) ?></p>
</div>




<div class="tab-content active" id="live">
    <?php if ($live): ?>
        <?php foreach ($live as $l): ?>
            <div class="content-item">
                <h3><?= htmlspecialchars($l['title']) ?></h3>
                <p><?= nl2br(htmlspecialchars($l['description'] ?? '')) ?></p>
                <a href="<?= htmlspecialchars($l['link']) ?>" target="_blank" class="btn btn-primary">Join Live Class</a>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No live class link available yet.</p>
    <?php endif; ?>
</div>

<div class="tab-content" id="recordings">
    <?php if ($recordings): ?>
        <?php foreach ($recordings as $r): ?>
            <div class="content-item">
                <h3><?= htmlspecialchars($r['title']) ?></h3>
                <p><?= nl2br(htmlspecialchars($r['description'] ?? '')) ?></p>
                <?php if (!empty($r['link']) && filter_var($r['link'], FILTER_VALIDATE_URL) && in_array(strtolower((string)parse_url($r['link'], PHP_URL_SCHEME)), ['http', 'https'], true)): ?>
                    <a href="<?= htmlspecialchars($r['link'], ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener noreferrer" class="btn btn-primary">Open Recording Link</a>
                <?php endif; ?>
                <?php if (!empty($r['file_path'])): ?>
                    <a href="/assets/uploads/recordings/<?= rawurlencode(basename($r['file_path'])) ?>" target="_blank" rel="noopener noreferrer" class="btn btn-outline">Watch / Download File</a>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No recordings uploaded yet.</p>
    <?php endif; ?>
</div>

<div class="tab-content" id="notes">
    <?php if ($notes): ?>
        <?php foreach ($notes as $n): ?>
            <div class="content-item">
                <h3><?= htmlspecialchars($n['title']) ?></h3>
                <p><?= nl2br(htmlspecialchars($n['description'] ?? '')) ?></p>
                <?php if (!empty($n['link']) && filter_var($n['link'], FILTER_VALIDATE_URL) && in_array(strtolower((string)parse_url($n['link'], PHP_URL_SCHEME)), ['http', 'https'], true)): ?>
                    <a href="<?= htmlspecialchars($n['link'], ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener noreferrer" class="btn btn-primary">Open Note / Tute Link</a>
                <?php endif; ?>
                <?php if (!empty($n['file_path'])): ?>
                    <a href="/assets/uploads/notes/<?= rawurlencode(basename($n['file_path'])) ?>" target="_blank" rel="noopener noreferrer" class="btn btn-outline">Download Note File</a>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No notes available yet.</p>
    <?php endif; ?>
</div>

<div class="tab-content" id="notices">
    <?php if ($notices): ?>
        <?php foreach ($notices as $n): ?>
            <div class="content-item">
                <h3><?= htmlspecialchars($n['title']) ?></h3>
                <p><?= nl2br(htmlspecialchars($n['description'] ?? '')) ?></p>
                <small><?= $n['created_at'] ?></small>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No notices yet.</p>
    <?php endif; ?>
</div>

<div class="class-tabs">
    <button class="tab-btn active" data-tab="live">
        <span class="tab-icon">📡</span> Live Class
    </button>
    <button class="tab-btn" data-tab="recordings">
        <span class="tab-icon">🎬</span> Recordings
    </button>
    <button class="tab-btn" data-tab="notes">
        <span class="tab-icon">📄</span> Notes / Tutes
    </button>
    <button class="tab-btn" data-tab="notices">
        <span class="tab-icon">📢</span> Notices
    </button>
</div>

<?php require '../includes/footer.php'; ?>
