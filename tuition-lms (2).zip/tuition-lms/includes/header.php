<?php
require_once __DIR__ . '/auth.php';
$user = currentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? 'Tuition LMS' ?></title>
    <link rel="stylesheet" href="/assets/css/style.css?v=3">
</head>
<body>

<header class="modern-navbar">
    <div class="container nav-container">
        <!-- Logo -->
        <a href="<?= BASE_URL ?>/" class="nav-logo">
            <img src="/assets/images/ICT.png" alt="ICT with Dhananjaya" class="logo-png">
        </a>

        <?php if (!$user): ?>
            <nav class="nav-menu" aria-label="Primary navigation">
                <a href="<?= BASE_URL ?>/" class="nav-link active">Home</a>
                <a href="<?= BASE_URL ?>/#courses" class="nav-link">Courses</a>
                <a href="<?= BASE_URL ?>/#educator" class="nav-link">About</a>
                <a href="<?= BASE_URL ?>/#reviews-section" class="nav-link">Reviews</a>
                <a href="https://wa.me/<?= WHATSAPP_NUMBER ?>?text=<?= rawurlencode('Hi, I would like to know more about your ICT classes.') ?>" class="nav-link" target="_blank" rel="noopener noreferrer">Contact</a>
            </nav>
        <?php endif; ?>

        <!-- Right Side -->
        <div class="nav-right">
            <?php if ($user): ?>
                <span class="nav-user">Hi, <?= htmlspecialchars($user['name']) ?></span>
                <a href="<?= BASE_URL ?>/<?= $user['role'] === 'teacher' ? 'teacher' : 'student' ?>/dashboard.php" class="btn-login">Dashboard</a>
                <a href="<?= BASE_URL ?>/logout.php" class="btn-signup">Logout</a>
            <?php else: ?>
                <div class="nav-search">
                    <input type="text" placeholder="Search...">
                </div>
                <a href="<?= BASE_URL ?>/login.php" class="btn-login">Log in</a>
                <a href="<?= BASE_URL ?>/register.php" class="btn-signup">Sign up →</a>
            <?php endif; ?>
        </div>
    </div>
</header>

<main class="container">